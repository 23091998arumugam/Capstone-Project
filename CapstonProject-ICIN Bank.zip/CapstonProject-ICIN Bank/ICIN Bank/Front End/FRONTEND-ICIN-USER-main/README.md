# AngularApp

PART-2  ANGUALR USER PANNEL 


This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 10.0.1.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).



![transferHistory](https://user-images.githubusercontent.com/86375697/191460619-f4dea31e-b4c7-4858-8e35-5533939f09b9.png)
![transfermoney](https://user-images.githubusercontent.com/86375697/191460623-183884ec-e9b2-4d9e-885b-00a0557cbfef.png)
![user](https://user-images.githubusercontent.com/86375697/191460627-971f8252-5157-4e84-be9b-03547e96052a.png)
![userHome](https://user-images.githubusercontent.com/86375697/191460630-c8d4befd-109b-4274-abff-c76e88b62079.png)
![withdrawMoney](https://user-images.githubusercontent.com/86375697/191460632-4dee8575-2205-4848-b456-2646e8bb734e.png)
![Profile Setting](https://user-images.githubusercontent.com/86375697/191460635-740a23ce-28f5-4daa-b4bc-75529f377ffe.png)
![Request check Book](https://user-images.githubusercontent.com/86375697/191460639-e6e8dfb3-ee81-41a4-bf94-e1be42002cca.png)
![transactionistory](https://user-images.githubusercontent.com/86375697/191460641-32cf9663-a283-42d5-b2f8-75c273b6ac4e.png)



