export class TransferHistory{
        id:number;
        saccount:string;
        raccount:string;
        amount:number;
        date:Date;
}