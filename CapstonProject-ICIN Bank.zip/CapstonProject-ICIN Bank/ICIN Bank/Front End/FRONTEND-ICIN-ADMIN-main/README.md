ICIN -PROJECT
PART-1 Thsi is the Angular Admin Pannel 

Admin Portal![AdminUserAcc](https://user-images.githubusercontent.com/86375697/191459939-c5def88b-3762-42bf-9ea4-b7f5bb519fa7.png)
![AminAuthorize](https://user-images.githubusercontent.com/86375697/191459972-035e8c19-e919-4172-896f-9c9a0d3e9da7.png)
![CheckRequests](https://user-images.githubusercontent.com/86375697/191459991-dbd3f8a2-13a2-40cf-8590-eb20975bfe9c.png)

