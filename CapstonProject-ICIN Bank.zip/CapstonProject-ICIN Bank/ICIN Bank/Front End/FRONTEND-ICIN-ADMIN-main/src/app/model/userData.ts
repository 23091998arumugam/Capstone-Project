export class UserData{
    fname:string;
    lname: string;
    username: string;
    email: string;
    account: number;
    saccount: number;
}
